import java.util.ArrayList;
        
public class Reserva {
    
    private ArrayList<Hospede> hospedes;
    private Suite suite;
    private int quantidadePessoas;
    private int quantidadeDias;
    
    Reserva (ArrayList<Hospede> hospedes, Suite suite, int quantidadeDias) {
        this.hospedes = hospedes;
        this.suite = suite;
        for (int i = 0; i < this.hospedes.size(); i++) {
            if (this.hospedes.get(i).getIdade() > 2) {
                this.quantidadePessoas = this.quantidadePessoas + 1;
            }
        }
        this.quantidadeDias = quantidadeDias;        
    }
    
    public int getQuantidadePessoas () {
        return this.quantidadePessoas;
    }
    
    public int getQuantidadeDias () {
        return this.quantidadeDias;
    }
    
    public boolean verificarCapacidade() {
        if (this.getQuantidadePessoas() <= this.suite.getCapacidade()) {
            return true;
        } else {
            return false;
        }
    }
    
    public double calcularDiaria() {
        if (getQuantidadeDias() <= 7) {
            return this.suite.getValorDiaria() * this.quantidadeDias;
        } else {
            return 0.9*(this.suite.getValorDiaria() * this.quantidadeDias);
        }
    }
    
}