public class Hospede {
    
    private int codigo;
    private String nome;
    private String endereco;
    private int idade;
    
    Hospede (int codigo, String nome, String endereco, int idade) {
        setCodigo(codigo);
        setNome(nome);
        setEndereco(endereco);
        setIdade(idade);
    }
    
    public int getCodigo () {
        return this.codigo;
    }
    
    public String getNome () {
        return this.nome;
    }
    
    public String getEndereco () {
        return this.endereco;
    }
    
    public int getIdade () {
        return this.idade;
    }
    
    public void setCodigo (int codigo) {
        this.codigo = codigo;
    }
    
    public void setNome (String nome) {
        this.nome = nome;
    }
    
    public void setEndereco (String endereco) {
        this.endereco = endereco;
    }
    
    public void setIdade (int idade) {
        this.idade = idade;
    }
    
    @Override
    public String toString() {
        return "{ codigo: " + this.codigo + ", nome: " + this.nome + ", endereco: " + this.endereco + ", " + this.endereco + ", idade: " + this.idade + " }";
    }
    
}